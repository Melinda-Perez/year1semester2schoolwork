public interface TreeMin<T extends Comparable<T>> {
    T minimum(Node<T> node);
}
