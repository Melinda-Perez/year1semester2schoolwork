public interface ArrayMin<T extends Comparable<T>> {
    T minimum(T[] array);
}
